package dev.haziqkamel.countriesmvvmdemo.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import dev.haziqkamel.countriesmvvmdemo.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}