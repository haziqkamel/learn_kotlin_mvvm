package dev.haziqkamel.countriesmvvmdemo.viewmodel

import androidx.lifecycle.ViewModel

class ListViewModel : ViewModel() {



}