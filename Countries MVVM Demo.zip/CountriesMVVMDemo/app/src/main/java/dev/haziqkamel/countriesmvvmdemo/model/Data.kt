package dev.haziqkamel.countriesmvvmdemo.model

// Model
data class Country(val countryName: String?)